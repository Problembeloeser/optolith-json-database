# Archetypen aus DSA 5 Grundregelwerk (3. Auflage)
### erstellt mit Optolith 1.2.0

- AP Kosten für Rondrageweihte zu hoch
- AP Kosten für Zwergischen Krieger zu hoch
- AP Kosten für Wildnisläuferin zu niedrig