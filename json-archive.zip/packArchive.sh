#!/bin/bash

rm json-archive.zip
7z a json-archive.zip *
