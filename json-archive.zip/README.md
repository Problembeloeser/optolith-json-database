Optolith JSON Database
---

This repository should contain a database for example/archetype heroes, for inspiration or quick NPC generation.